Source files of the Java based sanity check for the [Free Cities game](https://gitgud.io/pregmodfan/fc-pregmod).

Using Aho-Corasick implementation by RokLenarcic:
https://github.com/RokLenarcic/AhoCorasick/

Using [Jansi](https://fusesource.github.io/jansi/) for colored output.