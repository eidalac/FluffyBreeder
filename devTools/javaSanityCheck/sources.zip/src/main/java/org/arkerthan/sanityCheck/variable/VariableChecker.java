package org.arkerthan.sanityCheck.variable;

import org.arkerthan.sanityCheck.CharHandler;
import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.Position;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

/**
 * @author Arkerthan
 */
@SuppressWarnings("SpellCheckingInspection")
public class VariableChecker implements CharHandler {
    private final VariableSearchTree tree;
    private int state = 0;
    private int openArrays = 0;
    private StringBuilder b;
    private char lastChar;
    private boolean disabled = false; /* no-usedOnce */ /* usedOnce */

    public VariableChecker() {
        tree = new VariableSearchTree();

        //preload false positives
        try {
            Files.lines(new File("devTools/javaSanityCheck/ignoredVariables").toPath()).map(String::trim)
                    .filter(s -> !s.startsWith("#"))
                    .forEach(s -> {
                        String[] sa = s.split(";");
                        for (String ss :
                                sa) {
                            tree.add(Position.LOADING, ss, true, true);
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Error> getErrors() {
        return tree.getErrors();
    }

    @Override
    public void handleChar(char c, Position p, int fileType) {
        if (fileType == CharHandler.TW_FILE) {
            twHandleChar(p, c);
        } else if (fileType == CharHandler.JS_FILE) {
            jsHandleChar(p, c);
        }
    }

    @Override
    public void nextFile() {
        state = 0;
        openArrays = 0;
        disabled = false;
    }

    /*
    0: nothing
    1: TW: $ found, building String
    2: TW: _ found, waiting for .

    5: comment "/"
    6: comment "/*"
    7: comment "/**"
    8: JS: comment "//", waiting for "\n"

    10: JS: .. found, trash next
    11: JS: . found, building String
    12: JS: name found check for function
    13: JS: " =" after last name
    14: JS: " = " after last name or " = ("
    15: JS: " = f" after last name ...
    16: JS: " = fu" after last name
    17: JS: " = fun" after last name
    18: JS: " = func" after last name
    19: JS: " = funct" after last name
    20: JS: " = functi" after last name
    21: JS: " = functio" after last name
    22: JS: " = c" after last name
    23: JS: " = cl" after last name
    24: JS: " = cla" after last name
    25: JS: " = clas" after last name
     */

    /* no-usedOnce */ /* usedOnce */ /*
    30: "/* n"
    31: "/* no"
    32: "/* no-"
    33: "/* no-u"
    34: "/* no-us"
    35: "/* no-use"
    36: "/* no-used"
    37: "/* no-usedO"
    38: "/* no-usedOn"
    39: "/* no-usedOnc"
    40: "/* u"
    41: "/* us"
    42: "/* use"
    43: "/* used"
    44: "/* usedO"
    45: "/* usedOn"
    46: "/* usedOnc"

    TW: setup
    50: TW: "s"
    51: TW: "se"
    52: TW: "set"
    53: TW: "setu"

    TW: App
    55: "A"
    56: "Ap"
     */

    private void jsHandleChar(Position p, char c) {
        switch (state) {
            case 0:
                if (c == '.' && !Character.isDigit(lastChar)) {
                    state = 11;
                    b = new StringBuilder();
                } else if (c == '/') {
                    state = 5;
                } else if (c == ']') {
                    state = 11;
                    b = new StringBuilder();
                    openArrays--;
                }
                break;
            /*
            5: comment "/"
            6: comment "/*"
            7: comment "/**"
            */
            case 5:
                if (c == '*') {
                    state = 6;
                } else if (c == '/') {
                    state = 8;
                } else {
                    state = 0;
                }
                break;
            case 6:
                if (c == '*') {
                    state = 7;
                } else if (c == 'n') {
                    state = 30;
                } else if (c == 'u') {
                    state = 40;
                }
                break;
            case 7:
                if (c == '/') {
                    state = 0;
                } else {
                    state = 6;
                }
                break;
            case 8:
                if (c == '\n') {
                    state = 0;
                }
                break;
            case 10: // .. found, trashin next
                state = 0;
            case 11:
                switch (c) {
                    case '.':
                        if (lastChar != '.') {
                            tree.add(p, b.toString(), false);
                            b = new StringBuilder();
                        } else {
                            state = 10;
                        }
                        break;
                    case '[':
                        openArrays++;
                        state = 0;
                        break;
                    case ']':
                        if (openArrays > 0) {
                            openArrays--;
                        } else {
                            state = 0;
                        }
                        break;
                    case '(':
                        b = new StringBuilder();
                        state = 0;
                        break;
                    default:
                        if (Character.isLetterOrDigit(c)) {
                            b.append(c);
                        } else if (c == ' ') { //go into function checking
                            state = 12;
                        } else {
                            tree.add(p, b.toString(), false);
                            state = 0;
                        }
                }
                break;
            /*
            13: JS: " =" after last name
            14: JS: " = " after last name
            15: JS: " = f" after last name
            16: JS: " = fu" after last name
            17: JS: " = fun" after last name
            18: JS: " = func" after last name
            19: JS: " = funct" after last name
            20: JS: " = functi" after last name
            21: JS: " = functio" after last name
            */
            case 12:
                if (c == '=') {
                    state = 13;
                    break;
                } else if (c == '{') {
                    state = 0;
                    break;
                }
            case 13:
                if (c == ' ') {
                    state = 14;
                    break;
                }
            case 14:
                if (c == 'f') {
                    state = 15;
                    break;
                } else if (c == 'c') {
                    state = 22;
                    break;
                } else if (c == '(') {
                    break;
                }
            case 15:
                if (c == 'u') {
                    state = 16;
                    break;
                }
            case 16:
                if (c == 'n') {
                    state = 17;
                    break;
                }
            case 17:
                if (c == 'c') {
                    state = 18;
                    break;
                }
            case 18:
                if (c == 't') {
                    state = 19;
                    break;
                }
            case 19:
                if (c == 'i') {
                    state = 20;
                    break;
                }
            case 20:
                if (c == 'o') {
                    state = 21;
                    break;
                }
            case 21:
                if (c == 'n') {
                    state = 0;
                    break;
                }
            case 22:
                if (c == 'l') {
                    state = 23;
                    break;
                }
            case 23:
                if (c == 'a') {
                    state = 24;
                    break;
                }
            case 24:
                if (c == 's') {
                    state = 25;
                    break;
                }
            case 25:
                if (c == 's') {
                    state = 0;
                    break;
                } else {
                    tree.add(p, b.toString(), false);
                    state = 0;
                    jsHandleChar(p, c);
                }
                break;
/*
            22: JS: " = c" after last name
            23: JS: " = cl" after last name
            24: JS: " = cla" after last name
            25: JS: " = clas" after last name*/
                /*
    30: "/* n"
    31: "/* no"
    32: "/* no-"
    33: "/* no-u"
    34: "/* no-us"
    35: "/* no-use"
    36: "/* no-used"
    37: "/* no-usedO"
    38: "/* no-usedOn"
    39: "/* no-usedOnc"
    */
            case 30:
                if (c == 'o') {
                    state = 31;
                } else {
                    state = 6;
                }
                break;
            case 31:
                if (c == '-') {
                    state = 32;
                } else {
                    state = 6;
                }
                break;
            case 32:
                if (c == 'u') {
                    state = 33;
                } else {
                    state = 6;
                }
                break;
            case 33:
                if (c == 's') {
                    state = 34;
                } else {
                    state = 6;
                }
                break;
            case 34:
                if (c == 'e') {
                    state = 35;
                } else {
                    state = 6;
                }
                break;
            case 35:
                if (c == 'd') {
                    state = 36;
                } else {
                    state = 6;
                }
                break;
            case 36:
                if (c == 'O') {
                    state = 37;
                } else {
                    state = 6;
                }
                break;
            case 37:
                if (c == 'n') {
                    state = 38;
                } else {
                    state = 6;
                }
                break;
            case 38:
                if (c == 'c') {
                    state = 39;
                } else {
                    state = 6;
                }
                break;
            case 39:
                if (c == 'e') {
                    disabled = true;
                    state = 7;
                } else {
                    state = 6;
                }
                break;
                /*
    40: "/* u"
    41: "/* us"
    42: "/* use"
    43: "/* used"
    44: "/* usedO"
    45: "/* usedOn"
    46: "/* usedOnc"*/

            case 40:
                if (c == 's') {
                    state = 41;
                } else {
                    state = 6;
                }
                break;
            case 41:
                if (c == 'e') {
                    state = 42;
                } else {
                    state = 6;
                }
                break;
            case 42:
                if (c == 'd') {
                    state = 43;
                } else {
                    state = 6;
                }
                break;
            case 43:
                if (c == 'O') {
                    state = 44;
                } else {
                    state = 6;
                }
                break;
            case 44:
                if (c == 'n') {
                    state = 45;
                } else {
                    state = 6;
                }
                break;
            case 45:
                if (c == 'c') {
                    state = 46;
                } else {
                    state = 6;
                }
                break;
            case 46:
                if (c == 'e') {
                    disabled = false;
                    state = 7;
                } else {
                    state = 6;
                }
                break;
        }
        lastChar = c;
    }

    private void twHandleChar(Position p, char c) {
        switch (state) {
            case 0:
                if (c == '$') {
                    state = 1;
                    b = new StringBuilder();
                } else if (c == '_') {
                    state = 2;
                } else if (c == 's') {
                    state = 50;
                } else if (c == 'A') {
                    state = 55;
                } else if (c == '/') {
                    state = 5;
                } else if (c == ']') {
                    state = 1;
                    b = new StringBuilder();
                    openArrays--;
                }
                break;
            case 1:
                switch (c) {
                    case '.':
                        tree.add(p, b.toString(), !disabled);
                        b = new StringBuilder();
                        break;
                    case '[':
                        tree.add(p, b.toString(), !disabled);
                        openArrays++;
                        state = 0;
                        break;
                    case ']':
                        tree.add(p, b.toString(), !disabled);
                        if (openArrays > 0) {
                            openArrays--;
                            b = new StringBuilder();
                        } else {
                            state = 0;
                        }
                        break;
                    case '(':
                        b = new StringBuilder();
                        state = 0;
                        break;
                    default:
                        if (Character.isLetterOrDigit(c)) {
                            b.append(c);
                        } else {
                            tree.add(p, b.toString(), !disabled);
                            state = 0;
                        }
                }
                break;
            case 2:
                switch (c) {
                    case '.':
                        b = new StringBuilder();
                        state = 1;
                        break;
                    case '[':
                        openArrays++;
                        state = 0;
                        break;
                    case ']':
                        if (openArrays > 0) {
                            openArrays--;
                            state = 1;
                            b = new StringBuilder();
                        } else {
                            state = 0;
                        }
                        break;
                    default:
                        if (!Character.isLetterOrDigit(c)) {
                            state = 0;
                        }
                }
                break;
            /*
            5: comment "/"
            6: comment "/*"
            7: comment "/**"
            */
            case 5:
                if (c == '*') {
                    state = 6;
                } else if (c != '/') {
                    state = 0;
                }
                break;
            case 6:
                if (c == '*') {
                    state = 7;
                } else if (c == 'n') {
                    state = 30;
                } else if (c == 'u') {
                    state = 40;
                }
                break;
            case 7:
                if (c == '/') {
                    state = 0;
                } else {
                    state = 6;
                }
                break;
                /*
    30: "/* n"
    31: "/* no"
    32: "/* no-"
    33: "/* no-u"
    34: "/* no-us"
    35: "/* no-use"
    36: "/* no-used"
    37: "/* no-usedO"
    38: "/* no-usedOn"
    39: "/* no-usedOnc"
    */
            case 30:
                if (c == 'o') {
                    state = 31;
                } else {
                    state = 6;
                }
                break;
            case 31:
                if (c == '-') {
                    state = 32;
                } else {
                    state = 6;
                }
                break;
            case 32:
                if (c == 'u') {
                    state = 33;
                } else {
                    state = 6;
                }
                break;
            case 33:
                if (c == 's') {
                    state = 34;
                } else {
                    state = 6;
                }
                break;
            case 34:
                if (c == 'e') {
                    state = 35;
                } else {
                    state = 6;
                }
                break;
            case 35:
                if (c == 'd') {
                    state = 36;
                } else {
                    state = 6;
                }
                break;
            case 36:
                if (c == 'O') {
                    state = 37;
                } else {
                    state = 6;
                }
                break;
            case 37:
                if (c == 'n') {
                    state = 38;
                } else {
                    state = 6;
                }
                break;
            case 38:
                if (c == 'c') {
                    state = 39;
                } else {
                    state = 6;
                }
                break;
            case 39:
                if (c == 'e') {
                    disabled = true;
                    state = 7;
                } else {
                    state = 6;
                }
                break;
                /*
    40: "/* u"
    41: "/* us"
    42: "/* use"
    43: "/* used"
    44: "/* usedO"
    45: "/* usedOn"
    46: "/* usedOnc"*/

            case 40:
                if (c == 's') {
                    state = 41;
                } else {
                    state = 6;
                }
                break;
            case 41:
                if (c == 'e') {
                    state = 42;
                } else {
                    state = 6;
                }
                break;
            case 42:
                if (c == 'd') {
                    state = 43;
                } else {
                    state = 6;
                }
                break;
            case 43:
                if (c == 'O') {
                    state = 44;
                } else {
                    state = 6;
                }
                break;
            case 44:
                if (c == 'n') {
                    state = 45;
                } else {
                    state = 6;
                }
                break;
            case 45:
                if (c == 'c') {
                    state = 46;
                } else {
                    state = 6;
                }
                break;
            case 46:
                if (c == 'e') {
                    disabled = false;
                    state = 7;
                } else {
                    state = 6;
                }
                break;
            /*
            TW: setup
            50: TW: "s"
            51: TW: "se"
            52: TW: "set"
            53: TW: "setu"
            54: TW: "setup"*/
            case 50:
                if (c == 'e') {
                    state = 51;
                } else {
                    state = 0;
                }
                break;
            case 51:
                if (c == 't') {
                    state = 52;
                } else {
                    state = 0;
                }
                break;
            case 52:
                if (c == 'u') {
                    state = 53;
                } else {
                    state = 0;
                }
                break;
            case 53:
                if (c == 'p') {
                    state = 54;
                } else {
                    state = 0;
                }
                break;
            case 54:
                if (c == '.') {
                    state = 1;
                    b = new StringBuilder();
                } else {
                    state = 0;
                }
                break;
            /*
            55: "A"
            56: "Ap"
            57: "App"
            */
            case 55:
                if (c == 'p') {
                    state = 56;
                } else {
                    state = 0;
                }
                break;
            case 56:
                if (c == 'p') {
                    state = 57;
                } else {
                    state = 0;
                }
                break;
            case 57:
                if (c == '.') {
                    state = 1;
                    b = new StringBuilder();
                } else {
                    state = 0;
                }
                break;

        }
        lastChar = c;
    }
}
