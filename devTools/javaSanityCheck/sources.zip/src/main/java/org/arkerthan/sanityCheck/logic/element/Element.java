package org.arkerthan.sanityCheck.logic.element;

import org.arkerthan.sanityCheck.logic.SyntaxError;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 */
public abstract class Element {
    protected final int line;
    protected final int pos;
    protected KnownElement k;

    /**
     * @param line Line the instance was created
     * @param pos  Position in line the instance was created
     */
    protected Element(int line, int pos) {
        this.line = line;
        this.pos = pos;
    }

    /**
     * Parses a Char and returns an int depending on the state of the element
     * 0 - the Element did nothing
     * 1 - the Element changed state
     * 2 - the Element is finished
     * 3 - the Element is finished and a KnownHtmlElement was generated
     * 4 - the Element is finished and the char is still open for use
     *
     * @param c char to be parsed
     * @return state change
     * @throws SyntaxError thrown when an syntax error is detected
     */
    public abstract int handleChar(char c) throws SyntaxError;

    /**
     * @return the constructed KnownElement. null if none was constructed yet.
     */
    public KnownElement getKnownElement() {
        return k;
    }

    /**
     * Returns the line and position of the Element in the file it was created in.
     *
     * @return position of Element in file as String
     */
    public String getPositionAsString() {
        return "[" + ansi().fgBlue().a(line + ":" + pos).reset().toString() + "]";
    }

    /**
     * @return a short description usually based on state and position of the Element
     */
    public abstract String getShortDescription();
}
