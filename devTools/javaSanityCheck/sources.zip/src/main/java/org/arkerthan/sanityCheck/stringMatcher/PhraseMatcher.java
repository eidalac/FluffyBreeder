package org.arkerthan.sanityCheck.stringMatcher;

import com.roklenarcic.util.strings.AhoCorasickMap;
import com.roklenarcic.util.strings.MapMatchListener;
import com.roklenarcic.util.strings.StringMap;
import com.roklenarcic.util.strings.WholeWordMatchMap;
import org.arkerthan.sanityCheck.CharHandler;
import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.Position;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 */
public class PhraseMatcher implements CharHandler {
    private final StringMap<String> phraseMap, wordMap, caseSensitive;
    private final MapMatchListener<String> listener;
    private final List<Error> errors = new LinkedList<>();
    private Position position;
    private StringBuilder builder;

    public PhraseMatcher() {
        Iterable<String>[] dict = loadPhrases("devTools/javaSanityCheck/dictionary_phrases.txt");
        phraseMap = new AhoCorasickMap<>(dict[0], dict[1], false);

        Iterable<String>[] dict2 = loadPhrases("devTools/javaSanityCheck/dictionary_wholeWords.txt");
        wordMap = new WholeWordMatchMap<>(dict2[0], dict2[1], false);

        Iterable<String>[] dict3 = loadPhrases("devTools/javaSanityCheck/dictionary_caseSensitive_phrases.txt");
        caseSensitive = new WholeWordMatchMap<>(dict3[0], dict3[1], true);

        listener = (s, start, end, value) -> {
            Position p = new Position(position);
            p.setColumn(start);
            errors.add(new MatchError(value, p));
            return true;
        };
    }

    /**
     * Loads search phrases and corresponding error messages from a specified file.
     * Returns an array of Iterables, the first entry is the search phrases, second is the corresponding error message.
     *
     * @param filePath path to load the phrases from
     * @return Array of Iterables
     */
    private static Iterable<String>[] loadPhrases(String filePath) {
        List<String> phrase = new LinkedList<>();
        List<String> value = new LinkedList<>();

        try {
            Files.lines(new File(filePath).toPath()).map(String::trim)
                    .filter(s -> !s.startsWith("#"))
                    .forEach(s -> {
                        String[] st = s.split("#");
                        phrase.add(st[0]);
                        value.add(ansi().fgRed().a(st[0]).reset()
                                .a("; Correct: ")
                                .fgGreen().a(st[1]).reset()
                                .toString());
                    });
        } catch (IOException e) {
            System.err.println("Couldn't read " + filePath);
        } catch (NullPointerException e) {
            System.err.println("Incorrect Line in " + filePath);
        }

        Iterable<String>[] dict = new Iterable[2];
        dict[0] = phrase;
        dict[1] = value;
        return dict;
    }

    @Override
    public void handleChar(char c, Position p, int fileType) {
        if (c == '\n') {
            match(builder.toString(), p);
            builder = new StringBuilder();
        } else {
            builder.append(c);
        }
    }

    @Override
    public void nextFile() {
        builder = new StringBuilder();
    }

    /**
     * Reads a String and searches for phrases specified in external files.
     *
     * @param s line to process
     * @param p Position of String
     */
    private void match(String s, Position p) {
        this.position = p;
        wordMap.match(s, listener);
        phraseMap.match(s, listener);
        caseSensitive.match(s, listener);
    }

    @Override
    public List<Error> getErrors() {
        return errors;
    }
}
