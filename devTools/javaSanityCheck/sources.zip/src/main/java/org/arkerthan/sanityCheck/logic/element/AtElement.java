package org.arkerthan.sanityCheck.logic.element;

import org.arkerthan.sanityCheck.UnknownStateException;
import org.arkerthan.sanityCheck.logic.SyntaxError;

/**
 * @author Arkerthan
 */
public class AtElement extends Element {
    private int state = 0;
    // 0 = @
    // 1 = @@
    // 2 = @@.
    // 3 = @@.a -- @@.ab -- @@.abc
    // 4 = @@.abc;abc
    // 5 = @@.abc;abc@

    // example: @@.red;some text@@

    public AtElement(int line, int pos) {
        super(line, pos);
    }

    @Override
    public int handleChar(char c) throws SyntaxError {
        switch (state) {
            case 0:
                state = 1;
                if (c == '@') {
                    return 1;
                } else {
                    if (c == '.') {
                        state = 2;
                    }
                    throw new SyntaxError("Opening \"@\" missing.", 1);
                }
            case 1:
                if (c == '.') {
                    state = 2;
                    return 1;
                } else {
                    state = 4;
                    throw new SyntaxError("\".\" missing, found \"" + c + "\". This might also indicate a " +
                            "missing closure in the previous color code.", 0, true);
                }
            case 2:
                state = 3;
                if (Character.isAlphabetic(c)) {
                    return 1;
                } else {
                    throw new SyntaxError("Identifier might be wrong.", 1, true);
                }
            case 3:
                if (c == ';') {
                    state = 4;
                    return 1;
                } else if (c == ' ') {
                    state = 4;
                    throw new SyntaxError("\";\" missing or wrong space.", 1);
                }
                break;
            case 4:
                if (c == '@') {
                    state = 5;
                    return 1;
                }
                break;
            case 5:
                if (c == '@') {
                    return 2;
                } else {
                    throw new SyntaxError("Closing \"@\" missing.", 2);
                }
            default:
                throw new UnknownStateException(state);
        }
        return 0;
    }

    @Override
    public String getShortDescription() {
        StringBuilder builder = new StringBuilder();
        builder.append(getPositionAsString()).append(" ");
        switch (state) {
            case 0:
                builder.append("@");
                break;
            case 1:
                builder.append("@@");
                break;
            case 2:
                builder.append("@@.");
                break;
            case 3:
                builder.append("@@.???");
                break;
            case 4:
                builder.append("@@???");
                break;
            case 5:
                builder.append("@@???@");
                break;
            default:
                throw new UnknownStateException(state);
        }
        return builder.toString();
    }
}
