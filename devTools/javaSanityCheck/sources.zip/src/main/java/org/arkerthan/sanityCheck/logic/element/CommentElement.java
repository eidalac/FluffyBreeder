package org.arkerthan.sanityCheck.logic.element;

import org.arkerthan.sanityCheck.UnknownStateException;
import org.arkerthan.sanityCheck.logic.SyntaxError;

/**
 * @author Arkerthan
 */
public class CommentElement extends Element {
    private int state = 0;
    /*
    0 - /
    1 - /*???
    2 - /*???*
    3 - /%???
    4 - /%???%
     */

    /**
     * @param line line in which comment starts
     * @param pos  position in line where comment starts
     */
    public CommentElement(int line, int pos) {
        super(line, pos);
    }

    @Override
    public int handleChar(char c) throws SyntaxError {
        switch (state) {
            case 0:
                if (c == '*') {
                    state = 1;
                } else if (c == '%') {
                    state = 3;
                } else if (c == '>') {
                    throw new SyntaxError("XHTML style closure", 4, true);
                } else {
                    return 4;
                }
                break;
            case 1:
                if (c == '*') {
                    state = 2;
                }
                break;
            case 2:
                if (c == '/') {
                    return 2;
                } else if (c == '*') {
                    return 1;
                }
                state = 1;
                break;
            case 3:
                if (c == '%') {
                    state = 4;
                }
                break;
            case 4:
                if (c == '/') {
                    return 2;
                }
                state = 3;
                break;
            default:
                throw new UnknownStateException(state);
        }
        return 1;
    }

    @Override
    public String getShortDescription() {
        return getPositionAsString() + "comment";
    }
}
