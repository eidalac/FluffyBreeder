package org.arkerthan.sanityCheck.logic.element;

import org.fusesource.jansi.Ansi;

/**
 * @author Arkerthan
 */
public class KnownHtmlElement extends KnownElement {

    private final boolean opening;
    private final String statement;

    /**
     * @param line      at which it begins
     * @param pos       at which it begins
     * @param opening   if it opens a tag: <tag>  or closes it: </tag>
     * @param statement statement inside the tag
     */
    public KnownHtmlElement(int line, int pos, boolean opening, String statement) {
        super(line, pos);
        this.opening = opening;
        this.statement = statement;
    }

    @Override
    public String getShortDescription() {
        Ansi a = Ansi.ansi();
        a.a(getPositionAsString()).fgRed().a(" <");
        if (!opening) {
            a.a("/");
        }
        return a.a(statement).a(">").reset().toString();
    }

    @Override
    public boolean isOpening() {
        return opening;
    }

    @Override
    public boolean isClosing() {
        return !opening;
    }

    @Override
    public boolean isMatchingElement(KnownElement k) {
        if (k instanceof KnownHtmlElement) {
            return ((KnownHtmlElement) k).statement.equals(this.statement);
        }
        return false;
    }
}
