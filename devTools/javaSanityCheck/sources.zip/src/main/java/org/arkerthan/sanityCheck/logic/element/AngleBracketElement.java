package org.arkerthan.sanityCheck.logic.element;

import org.arkerthan.sanityCheck.UnknownStateException;
import org.arkerthan.sanityCheck.logic.SyntaxChecker;
import org.arkerthan.sanityCheck.logic.SyntaxError;
import org.arkerthan.sanityCheck.logic.Tag;
import org.arkerthan.sanityCheck.logic.TagSearchTree;
import org.fusesource.jansi.Ansi;

import java.util.Arrays;
import java.util.List;

/**
 * @author Arkerthan
 */
public class AngleBracketElement extends Element {
    private static final List<String> logicTags = Arrays.asList("if", "elseif", "else", "switch", "case", "default");
    public int state = 0;
    /*
     0 - initial: <
     TWINE
     1 - <<
    -1 - <</
     2 - trying to complete twine tag: <<tag ???>>
    -2 - trying to complete twine tag: <</tag>>
     3 - waiting for >>
    -3 - expecting > from 3
     4 - waiting for >> with KnownElement
    -4 - expecting > from 4
     5 - expecting >>
    -5 - expecting >
     6 - expecting > with KnownElement opening; comparison?
    -6 - expecting > with KnownElement closing
     7 - ", expecting closing "
    -7 - ', expecting closing '
     8 - `, expecting closing `

     HTML
    -9 - </
    10 - trying to complete HTML tag: <tag ???>
   -10 - trying to complete HTML tag: </tag>
    11 - waiting for >
   -11 - expecting >
    12 - waiting for > with KnownElement
     */

    private TagSearchTree<Tag> tree;

    public AngleBracketElement(int line, int pos) {
        super(line, pos);
    }

    @Override
    public int handleChar(char c) throws SyntaxError {
        switch (state) {
            case 0:
                switch (c) {
                    case '<':
                        state = 1;
                        return 1;
                    case '/':
                        state = -9;
                        return 1;
                    case '>':// empty <>
                    case ' ':// assume comparison
                    case '='://    "        "
                    case '3':// a heart: <3
                        return 2;
                    default:
                        try {
                            state = 10;
                            tree = SyntaxChecker.htmlTags;
                            return handleOpeningHTML(c);
                        } catch (SyntaxError e) {
                            state = 1;
                            throw new SyntaxError("Opening \"<\" missing, found " + c, 1);
                        }
                }
            case 1:
                if (c == '<') {
                    throw new SyntaxError("Too many \"<\".", 1);
                } else if (c == '>') {
                    state = 3;
                    throw new SyntaxError("Empty Statement?", 1);
                } else if (c == '/') {
                    state = -1;
                    return 1;
                }
                state = 2;
                tree = SyntaxChecker.twineTags;
                return handleOpeningTwine(c);
            case -1:
                if (c == '>') {
                    throw new SyntaxError("Empty Statement?", 2, true);
                }
                state = -2;
                tree = SyntaxChecker.twineTags;
                return handleClosingTwine(c);

            case 2:
                return handleOpeningTwine(c);
            case -2:
                return handleClosingTwine(c);
            case 3:
                if (c == '>') {
                    state = -3;
                } else if (c == '"') {
                    state = 7;
                } else if (c == '\'') {
                    state = -7;
                } else if (c == '`') {
                    state = 8;
                }
                return 1;
            case -3:
                if (c == '>') {
                    return 2;
                } else if (c == ' ' || c == '=') { // assuming comparison
                    state = 3;
                    return 1;
                } else {
                    throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 2);
                }
            case 4:
                if (c == '>') {
                    state = -4;
                    return 1;
                }
                break;
            case -4:
                if (c == '>') {
                    return 3;
                } else if (c == ' ' || c == '=') { // assuming comparison
                    state = 4;
                    return 1;
                } else {
                    throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 2);
                }
            case 5:
                if (c == '>') {
                    state = -5;
                    return 1;
                } else {
                    throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 2);
                }
            case -5:
                if (c == '>') {
                    return 2;
                }
                throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 2);
            case 6:
                if (c == '>') {
                    return 3;
                } else if (c == ' ' || c == '=') {
                    state = 3;
                    return 1;
                } else {
                    throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 3);
                }
            case -6:
                if (c == '>') {
                    return 3;
                }
                throw new SyntaxError("Closing \">\" missing, opened tag at " + getPositionAsString(), 3);
            case 7:
                if (c == '"') {
                    state = 3;
                }
                return 1;
            case -7:
                if (c == '\'') {
                    state = 3;
                }
                return 1;
            case 8:
                if (c == '`') {
                    state = 3;
                }
                return 1;

            case -9:
                if (c == '>') {
                    throw new SyntaxError("Empty Statement?", 2, true);
                }
                state = -10;
                tree = SyntaxChecker.htmlTags;
                return handleClosingHTML(c);
            case 10:
                return handleOpeningHTML(c);
            case -10:
                return handleClosingHTML(c);
            case 11:
                if (c == '>')
                    return 2;
                if (c == '@') //@ inside HTML tags is allowed
                    return 1;
                break;
            case -11:
                if (c == '>')
                    return 2;
                throw new SyntaxError("Closing \">\" missing [2]", 2);
            case 12:
                if (c == '>')
                    return 3;
                if (c == '@') //@ inside HTML tags is allowed
                    return 1;
                break;
            default:
                throw new UnknownStateException(state);
        }
        return 0;
    }

    private int handleOpeningHTML(char c) throws SyntaxError {
        if (c == ' ') {
            state = 11;
            if (tree.getElement() == null) {
                throw new SyntaxError("Unknown HTML tag", 1);
            }
            if (!tree.getElement().single) {
                k = new KnownHtmlElement(line, pos, true, tree.getElement().tag);
                state = 12;
                return 1;
            }
            return 1;
        }
        if (c == '>') {
            if (tree.getElement() == null) {
                throw new SyntaxError("Unknown HTML tag", 2);
            }
            if (!tree.getElement().single) {
                k = new KnownHtmlElement(line, pos, true, tree.getElement().tag);
                return 3;
            }
            return 2;
        }

        tree = tree.getBranch(c);
        if (tree == null) {
            state = 11;
            throw new SyntaxError("Unknown HTML tag or closing \">\" missing, found " + c, 1);
        }

        return 1;
    }

    private int handleClosingHTML(char c) throws SyntaxError {
        if (c == '>') {
            if (tree.getElement() == null) {
                throw new SyntaxError("Unknown HTML tag: " + tree.getPath(), 2);
            }
            if (tree.getElement().single) {
                throw new SyntaxError("Single HTML tag used as closing Tag: " + tree.getElement().tag, 2);
            }
            k = new KnownHtmlElement(line, pos, false, tree.getElement().tag);
            return 3;
        }

        tree = tree.getBranch(c);
        if (tree == null) {
            state = -11;
            throw new SyntaxError("Unknown HTML tag or closing \">\" missing, found " + c, 1);
        }

        return 1;
    }


    private int handleOpeningTwine(char c) {
        if (c == ' ') {
            state = 3;
            if (tree.getElement() == null) {
                //assuming not listed means widget until better solution
                return 1;
            }
            if (!tree.getElement().single) {
                if (logicTags.contains(tree.getElement().tag)) {
                    k = new KnownLogicElement(line, pos, tree.getElement().tag, false);
                } else {
                    k = new KnownTwineElement(line, pos, true, tree.getElement().tag);
                }
                state = 4;
                return 1;
            }
            return 1;
        }
        if (c == '>') {
            state = -5;
            if (tree.getElement() == null) {
                //assuming not listed means widget until better solution
                return 1;
            }
            if (!tree.getElement().single) {
                if (logicTags.contains(tree.getElement().tag)) {
                    k = new KnownLogicElement(line, pos, tree.getElement().tag, false);
                } else {
                    k = new KnownTwineElement(line, pos, true, tree.getElement().tag);
                }
                state = 6;
                return 1;
            }
            return 2;
        }

        tree = tree.getBranch(c);
        if (tree == null) {
            //assuming not listed means widget until better solution
            state = 3;
        }

        return 1;
    }

    @SuppressWarnings("SameReturnValue")
    private int handleClosingTwine(char c) throws SyntaxError {
        if (c == '>') {
            if (tree.getElement() == null) {
                throw new SyntaxError("Unknown Twine tag: " + tree.getPath(), 2);
            }
            if (tree.getElement().single) {
                throw new SyntaxError("Single Twine tag used as closing Tag: " + tree.getElement().tag, 2);
            }
            if (logicTags.contains(tree.getElement().tag)) {
                k = new KnownLogicElement(line, pos, tree.getElement().tag, true);
            } else {
                k = new KnownTwineElement(line, pos, false, tree.getElement().tag);
            }
            state = -6;
            return 1;
        }

        tree = tree.getBranch(c);
        if (tree == null) {
            state = 3;
            throw new SyntaxError("Unknown Twine closing tag or closing \">>\" missing, found " + c, 1);
        }

        return 1;
    }

    @Override
    public String getShortDescription() {
        Ansi a = Ansi.ansi();
        a.a(getPositionAsString()).fgRed().a(" ");
        switch (state) {
            case 0:
                a.a("<");
                break;
            //TWINE
            case 1:
                a.a("<<");
                break;
            case -1:
                a.a("<</");
                break;
            case 2:
                a.a("<<").a(tree.getPath());
                break;
            case -2:
                a.a("<</").a(tree.getPath());
                break;
            case 3:
                a.a("<<???");
                break;
            case -3:
                a.a("<<???>");
                break;
            case 4:
                a.a("<<").a(tree.getPath()).a(" ???");
                break;
            case -4:
                a.a("<<").a(tree.getPath()).a(" ???>");
                break;
            case 5:
                a.a("<<???");
                break;
            case -5:
                a.a("<<").a(tree == null ? "???" : tree.getPath()).a(">");
                break;
            case 6:
                a.a("<<").a(tree.getPath()).a(" ???>");
                break;
            case -6:
                a.a("<</").a(tree.getPath()).a(">");
                break;
            case 7:
                a.a("<<???\"???");
                break;
            case -7:
                a.a("<<???'???");
                break;
            case 8:
                a.a("<<???`???");
                break;
            //HTML
            case -9:
                a.a("</");
                break;
            case 10:
                a.a("<").a(tree.getPath());
                break;
            case -10:
                a.a("</").a(tree.getPath());
                break;
            case 11:
                a.a("<?").a(tree == null ? "???" : tree.getPath());
                break;
            case -11:
                a.a("</").a(tree == null ? "???" : tree.getPath());
                break;
            case 12:
                a.a("<").a(tree.getPath()).a(" ???");
                break;
            default:
                throw new UnknownStateException(state);
        }
        return a.reset().toString();
    }
}
