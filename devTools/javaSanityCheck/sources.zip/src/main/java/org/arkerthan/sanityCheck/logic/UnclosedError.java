package org.arkerthan.sanityCheck.logic;

import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.ErrorType;
import org.arkerthan.sanityCheck.Position;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 */
public class UnclosedError implements Error {
    private final String message;
    private final Position position;

    public UnclosedError(String message, String file) {
        this.message = message;
        this.position = Position.getEof(file);
    }

    @Override
    public String getErrorMessage() {
        return ansi().fgRed().bold().a("LogicError").reset().toString() + "  : " + position + ": tag not closed: " + message;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.LOGIC;
    }
}
