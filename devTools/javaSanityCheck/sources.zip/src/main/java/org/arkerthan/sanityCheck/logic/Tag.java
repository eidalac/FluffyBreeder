package org.arkerthan.sanityCheck.logic;

/**
 * @author Arkerthan
 */
public class Tag {
    public final String tag;
    public final boolean single;

    public Tag(String tag, boolean single) {
        this.tag = tag;
        this.single = single;
    }
}
