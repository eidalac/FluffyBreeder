package org.arkerthan.sanityCheck;

/**
 * @author Arkerthan
 */
public class UnknownStateException extends RuntimeException {

    public UnknownStateException(int state) {
        super(String.valueOf(state));
    }
}
