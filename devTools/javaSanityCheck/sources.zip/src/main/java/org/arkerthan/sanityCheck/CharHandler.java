package org.arkerthan.sanityCheck;

import java.util.List;

/**
 * @author Arkerthan
 */
public interface CharHandler {
    int TW_FILE = 0;
    int JS_FILE = 1;

    /**
     * @param c        char to process
     * @param p        position
     * @param fileType file type as specified
     */
    void handleChar(char c, Position p, int fileType);

    /**
     * called before a new file is fed through {@link #handleChar(char, Position, int)}
     */
    void nextFile();

    /**
     * @return errors found during execution of {@link #handleChar(char, Position, int)}
     */
    List<Error> getErrors();
}
