package org.arkerthan.sanityCheck.logic;

import org.arkerthan.sanityCheck.CharHandler;
import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.Position;
import org.arkerthan.sanityCheck.logic.element.AngleBracketElement;
import org.arkerthan.sanityCheck.logic.element.CommentElement;
import org.arkerthan.sanityCheck.logic.element.Element;
import org.arkerthan.sanityCheck.logic.element.KnownElement;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/**
 * @author Arkerthan
 */
public class SyntaxChecker implements CharHandler {
    public static TagSearchTree<Tag> htmlTags, twineTags;
    private static String file;

    static {
        setupHtmlTags();
        setupTwineTags();
    }

    private final List<Error> errors = new LinkedList<>();
    private Stack<Element> stack = new Stack<>();

    /**
     * sets up a {@link TagSearchTree<Tag>} for fast access of HTML tags later
     */
    private static void setupHtmlTags() {
        //load HTML tags into a list
        List<Tag> TagsList = loadTags("devTools/javaSanityCheck/htmlTags");

        //turn List into alphabetical search tree
        try {
            htmlTags = new TagSearchTree<>(TagsList);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Illegal Character in devTools/javaSanityCheck/htmlTags");
            System.exit(-1);
        }
    }

    /**
     * sets up a {@link TagSearchTree<Tag>} for fast access of twine tags later
     */
    private static void setupTwineTags() {
        //load twine tags into a list
        List<Tag> tagsList = loadTags("devTools/javaSanityCheck/twineTags");

        //turn List into alphabetical search tree
        try {
            twineTags = new TagSearchTree<>(tagsList);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Illegal Character in devTools/javaSanityCheck/twineTags");
            System.exit(-1);
        }
    }

    /**
     * Loads a list of tags from a file
     *
     * @param filePath file to load tags from
     * @return loaded tags
     */
    private static List<Tag> loadTags(String filePath) {
        List<Tag> tagsList = new LinkedList<>();
        try {
            Files.lines(new File(filePath).toPath()).map(String::trim)
                    .filter(s -> !s.startsWith("#"))
                    .forEach(s -> tagsList.add(parseTag(s)));
        } catch (IOException e) {
            System.err.println("Couldn't read " + filePath);
        }
        return tagsList;
    }

    /**
     * Turns a string into a Tag
     * ";1" at the end of the String indicates that the tag needs to be closed later
     *
     * @param s tag as String
     * @return tag as Tag
     */
    private static Tag parseTag(String s) {
        String[] st = s.split(";");
        if (st.length > 1 && st[1].equals("1")) {
            return new Tag(st[0], false);
        }
        return new Tag(st[0], true);
    }

    /**
     * add an error to the error list
     *
     * @param e new error
     */
    private void addError(SyntaxError e, Position p) {
        e.setPosition(p);
        errors.add(e);
    }

    @Override
    public void handleChar(char c, Position p, int fileType) {
        if (fileType != TW_FILE) return;
        file = p.getFile();

        if (!stack.empty()) {
            int change;
            try {
                change = stack.peek().handleChar(c);
            } catch (SyntaxError e) {
                change = e.getChange();
                addError(e, p);
            }

            //change greater 0 means the innermost element did some work
            if (change > 0) {
                //2 means the Element is complete
                if (change == 2) {
                    //remove the topmost element from stack since it is complete
                    stack.pop();
                    return;
                }
                //3 means the Element is complete and part of a two or more tag system
                if (change == 3) {
                    //remove the topmost element from stack since it is complete
                    KnownElement k = stack.pop().getKnownElement();
                    //if KnownElement k is closing another element, check if there is one and remove it
                    if (k.isClosing()) {
                        if (stack.empty()) { //there are no open elements at all
                            addError(new SyntaxError("Closed tag " + k.getShortDescription() + " without " +
                                    "having any open tags.", -2), p);
                        } else if (stack.peek() instanceof KnownElement) {
                            //get opening tag
                            KnownElement kFirst = (KnownElement) stack.pop();
                            //check if closing element matches the opening element
                            if (!kFirst.isMatchingElement(k)) {
                                addError(new SyntaxError("Opening tag " + kFirst.getShortDescription() +
                                        " does not match closing tag " + k.getShortDescription() + ".", -2), p);
                            }
                        } else {
                            //There closing tag inside another not Known element: <div </html>
                            addError(new SyntaxError("Closing tag " + k.getShortDescription() + " inside " +
                                    "another tag " + stack.peek().getShortDescription() + " without opening first.",
                                    -2, true), p);
                        }
                    }
                    //check if the element needs to be closed by another
                    if (k.isOpening()) {
                        stack.push(k);
                    }
                    return;
                }
                //means the element couldn't do anything with it and is finished
                if (change == 4) {
                    stack.pop();
                } else {
                    return;
                }
            }
        }

        //innermost element was uninterested, trying to find matching element
        switch (c) {
            //case '@':
            //stack.push(new AtElement(currentLine, currentPosition));
            //break;
            case '<':
                stack.push(new AngleBracketElement(p.getLine(), p.getColumn()));
                break;
            //case '>':
            //addError(new SyntaxError("Dangling \">\", current innermost: " + (stack.empty() ? "null" : stack.peek().getShortDescription()), -2));
            //break;
            case '/':
                stack.push(new CommentElement(p.getLine(), p.getColumn()));
                break;
            //case '(':
            //    stack.push(new BracketElement(currentLine, currentPosition));
        }

    }

    @Override
    public void nextFile() {
        stack.forEach(element -> errors.add(new UnclosedError(element.getShortDescription(), file)));
        stack = new Stack<>();
    }

    @Override
    public List<Error> getErrors() {
        return errors;
    }
}
