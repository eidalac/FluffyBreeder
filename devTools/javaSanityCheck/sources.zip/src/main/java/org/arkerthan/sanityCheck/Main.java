package org.arkerthan.sanityCheck;

import org.arkerthan.sanityCheck.logic.SyntaxChecker;
import org.arkerthan.sanityCheck.stringMatcher.PhraseMatcher;
import org.arkerthan.sanityCheck.variable.VariableChecker;
import org.fusesource.jansi.AnsiConsole;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * @author Arkerthan
 */
public class Main {

    private static String currentFile;
    private static int currentFileType, currentLine, currentPosition;
    private static Excluded[] excluded;
    private static SyntaxChecker syntaxChecker;
    private static VariableChecker varChecker;
    private static PhraseMatcher matcher;
    private static List<CharHandler> handlers;

    public static void main(String[] args) {
        if (isWindows()) {
            AnsiConsole.systemInstall();
        }
        //it seems like the toggle is inverted on linux

        //setup
        setupExclude();
        Path workingDir = Paths.get("").toAbsolutePath();
        syntaxChecker = new SyntaxChecker();
        syntaxChecker.nextFile();
        varChecker = new VariableChecker();
        varChecker.nextFile();
        matcher = new PhraseMatcher();
        matcher.nextFile();

        //run sanityCheck
        runSanityCheckInDirectory(workingDir, new File("src/").getAbsoluteFile());
        runSanityCheckInDirectory(workingDir, new File("js/").getAbsoluteFile());

        //output errors
        //sorted by error, then file
        syntaxChecker.getErrors().stream()
                .sorted()
                .forEach(error -> System.out.println(error.getErrorMessage()));

        varChecker.getErrors().stream()
                .filter(Main::isIncluded)
                .sorted()
                .forEach(error -> System.out.println(error.getErrorMessage()));

        matcher.getErrors().stream()
                .sorted()
                .forEach(error -> System.out.println(error.getErrorMessage()));
    }

    /**
     * Goes through the whole directory including subdirectories and runs
     * {@link Main#sanityCheck(Path)} on all .tw or .js files
     *
     * @param dir to be checked
     */
    private static void runSanityCheckInDirectory(Path workingDir, File dir) {
        //subdirectories are checked recursively
        try {
            for (File file : Objects.requireNonNull(dir.listFiles())) {
                if (file.isFile()) { //run sanityCheck if file is a .tw or js file
                    String path = file.getAbsolutePath();
                    if (path.endsWith(".tw")) {
                        currentFileType = CharHandler.TW_FILE;
                        sanityCheck(workingDir.relativize(file.toPath()));
                    } else if (path.endsWith(".js") && !path.endsWith(".min.js")) {
                        currentFileType = CharHandler.JS_FILE;
                        sanityCheck(workingDir.relativize(file.toPath()));
                    }
                } else if (file.isDirectory()) {
                    runSanityCheckInDirectory(workingDir, file.getAbsoluteFile());
                }
            }
        } catch (NullPointerException e) {
            System.err.println("Couldn't read directory " + dir.getPath() + "/ -- skipping");
        }
    }

    /**
     * Runs the sanity check for one file. Does not run if file is isExcluded.
     *
     * @param path file to be checked
     */
    private static void sanityCheck(Path path) {
        File file = path.toFile();

        // replace this with a known encoding if possible
        Charset encoding = Charset.defaultCharset();

        currentFile = file.getPath();
        currentLine = 1;

        handlers = new ArrayList<>();
        if (isIncluded(currentFile, ErrorType.LOGIC)) {
            handlers.add(syntaxChecker);
        }

        //always run variable check to reduce false positives due to using the same variable in and outside ignored files
        handlers.add(varChecker);

        if (isIncluded(currentFile, ErrorType.MATCH)) {
            handlers.add(matcher);
        }

        //actually opening and reading the file
        try (InputStream in = new FileInputStream(file);
             Reader reader = new InputStreamReader(in, encoding);
             // buffer for efficiency
             Reader buffer = new BufferedReader(reader)) {
            handleCharacters(buffer);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Couldn't read " + file);
        }
    }

    /**
     * Reads the file character by character.
     *
     * @param reader reader that is read
     * @throws IOException thrown if the file can't be read
     */
    private static void handleCharacters(Reader reader) throws IOException {
        int r;
        while ((r = reader.read()) != -1) {
            char c = (char) r;
            handleCharacter(c);
        }
        handleCharacter('\n'); //workaround for files that do not end with a new line
        for (CharHandler h :
                handlers) {
            h.nextFile();
        }

    }

    /**
     * Handles a single character
     *
     * @param c next character
     */
    private static void handleCharacter(char c) {
        //updating position
        currentPosition++;
        Position p = new Position(currentFile, currentLine, currentPosition);

        if (c == '\n') {
            currentLine++;
            currentPosition = 1;
        }

        for (CharHandler h :
                handlers) {
            h.handleChar(c, p, currentFileType);
        }
    }

    /**
     * sets up the excluded files array.
     */
    private static void setupExclude() {
        //load excluded files
        List<Excluded> excludedList = new ArrayList<>();
        try {
            Files.lines(new File("devTools/javaSanityCheck/excluded").toPath()).map(String::trim)
                    .filter(s -> !s.startsWith("#"))
                    .forEach(s -> {
                        String[] sa = s.split(";");
                        if (sa.length > 1) {
                            // change path to windows style if needed
                            if (isWindows()) {
                                sa[0] = sa[0].replaceAll("/", "\\\\");
                            }
                            //one line can exclude multiple checks
                            for (int i = 0; i < sa[1].length(); i++) {
                                try {
                                    excludedList.add(new Excluded(sa[0],
                                            ErrorType.getErrorType(sa[1].charAt(i))));
                                } catch (IllegalArgumentException e) {
                                    System.err.println(e.getMessage());
                                }
                            }
                        }
                    });
        } catch (IOException e) {
            System.err.println("Couldn't read devTools/javaSanityCheck/excluded");
        }

        //turn excluded files into an array
        excluded = excludedList.toArray(new Excluded[0]);
    }

    /**
     * @return whether OS is Windows or not
     */
    private static boolean isWindows() {
        return (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).contains("windows"));
    }

    /**
     * checks if a file or directory is excluded from a specific sanity check
     *
     * @param file file/directory to be checked
     * @param type type of error to be checked
     * @return whether it is excluded or not
     */
    private static boolean isIncluded(String file, ErrorType type) {
        for (Excluded ex :
                excluded) {
            if (ex.isExcluded(file, type)) return false;
        }
        return true;
    }

    /**
     * checks if an error is excluded from the sanity check
     *
     * @param e error to be checked
     * @return whether it is excluded or not
     */
    private static boolean isIncluded(Error e) {
        for (Excluded ex :
                excluded) {
            if (ex.isExcluded(e)) return false;
        }
        return true;
    }

    private static class Excluded {
        final String file;
        final ErrorType type;

        Excluded(String file, ErrorType type) {
            this.file = file;
            this.type = type;
        }

        boolean isExcluded(Error e) {
            return type == e.getErrorType() && e.getPosition().getFile().startsWith(file);
        }

        boolean isExcluded(String file, ErrorType type) {
            return this.type == type && file.startsWith(this.file);
        }
    }
}
