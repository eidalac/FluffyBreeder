package org.arkerthan.sanityCheck.logic.element;

import org.arkerthan.sanityCheck.UnknownStateException;
import org.arkerthan.sanityCheck.logic.DisallowedTagException;
import org.fusesource.jansi.Ansi;

/**
 * @author Arkerthan
 */
public class KnownLogicElement extends KnownElement {
    //private static final List<String> allowedTags = Arrays.asList("if", "elseif", "else");
    private final int state;
    private final boolean last;
    /*
    0 - if
    1 - elseif
    2 - else
    3 - switch
    4 - case
    5 - default
     */

    public KnownLogicElement(int line, int pos, String tag, boolean last) {
        super(line, pos);
        this.last = last;
        switch (tag) {
            case "if":
                state = 0;
                break;
            case "elseif":
                state = 1;
                break;
            case "else":
                state = 2;
                break;
            case "switch":
                state = 3;
                break;
            case "case":
                state = 4;
                break;
            case "default":
                state = 5;
                break;
            default:
                throw new DisallowedTagException(tag);
        }
    }

    @Override
    public boolean isOpening() {
        return !last;
    }

    @Override
    public boolean isClosing() {
        return (state != 0 && state != 3) || last;
    }

    @Override
    public boolean isMatchingElement(KnownElement k) {
        if (!(k instanceof KnownLogicElement)) {
            return false;
        }
        KnownLogicElement l = (KnownLogicElement) k;
        switch (state) {
            case 0:
            case 1:
                return l.state == 1 || l.state == 2 || (l.state == 0 && l.last);
            case 2:
                return l.state == 0 && l.last;
            case 3:
            case 4:
                return l.state == 3 || l.state == 4;
            case 5:
                return l.state == 3 && l.last;
            default:
                throw new UnknownStateException(state);
        }
    }

    @Override
    public String getShortDescription() {
        Ansi a = Ansi.ansi();
        a.a(getPositionAsString()).fgRed().a(" <<");
        if (last) {
            a.a('/');
        }
        switch (state) {
            case 0:
                a.a("if");
                break;
            case 1:
                a.a("elseif");
                break;
            case 2:
                a.a("else");
                break;
            case 3:
                a.a("switch");
                break;
            case 4:
                a.a("case");
                break;
            case 5:
                a.a("default");
                break;
            default:
                throw new UnknownStateException(state);
        }
        return a.a(">>").reset().toString();
    }
}
