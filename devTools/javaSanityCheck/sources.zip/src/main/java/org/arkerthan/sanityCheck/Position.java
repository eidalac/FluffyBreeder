package org.arkerthan.sanityCheck;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 */
public class Position implements Comparable<Position> {
    //Position used for loading phase
    public static final Position LOADING = new Position("LOADING", 0, 0) {
        @Override
        public String toString() {
            return "Error in config file";
        }
    };

    private final String file;
    private final int line;
    private int column;

    public Position(String file, int line, int column) {
        this.file = file;
        this.line = line;
        this.column = column;
    }

    /**
     * Creates a deep copy of a Position object
     *
     * @param p Position to copy
     */
    public Position(Position p) {
        this(p.file, p.line, p.column);
    }

    /**
     * Returns a position that indicates that the end of a file has been reached.
     *
     * @param file file of Position
     * @return Position at end of file
     */
    public static Position getEof(String file) {
        return new Position(file, Integer.MAX_VALUE, Integer.MAX_VALUE) {
            @Override
            public String toString() {
                return ansi().fgBrightYellow().a(file).reset()
                        .a(": ")
                        .fgBlue().a("EOF").reset()
                        .toString();
            }
        };
    }

    /**
     * @return file of Position
     */
    public String getFile() {
        return file;
    }

    /**
     * @return line of Position
     */
    public int getLine() {
        return line;
    }

    /**
     * @return column in line of Position
     */
    public int getColumn() {
        return column;
    }

    /**
     * @param column column in line of Position
     */
    public void setColumn(int column) {
        this.column = column;
    }

    @Override
    public String toString() {
        return ansi().fgBrightYellow().a(file).reset()
                .a(": ")
                .fgBlue().a(line + ":" + column).reset()
                .toString();
    }

    @Override
    public int compareTo(Position p) {
        int diff = this.file.compareToIgnoreCase(p.file);
        if (diff == 0) {
            if (this.line < p.line) {
                return -1;
            } else if (this.line > p.line) {
                return 1;
            } else {
                return Integer.compare(this.column, p.column);
            }
        } else {
            return diff;
        }
    }
}
