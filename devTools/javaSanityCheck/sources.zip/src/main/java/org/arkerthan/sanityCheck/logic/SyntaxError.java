package org.arkerthan.sanityCheck.logic;

import org.arkerthan.sanityCheck.Error;
import org.arkerthan.sanityCheck.ErrorType;
import org.arkerthan.sanityCheck.Position;

import static org.fusesource.jansi.Ansi.ansi;

/**
 * @author Arkerthan
 */
public class SyntaxError extends Exception implements Error {
    private static final String ERROR = ansi().fgRed().bold().a("LogicError").reset().a("  : ").toString();
    private static final String WARNING = ansi().fgYellow().bold().a("LogicWarning").reset().a(": ").toString();
    private final String description;
    private final int change; //see Element for values; -2 means not thrown
    private Position position;
    private boolean warning = false;

    /**
     * @param description description of error
     * @param change      state change as specified in Element
     */
    public SyntaxError(String description, int change) {
        this.description = description;
        this.change = change;
    }

    /**
     * @param description description of error
     * @param change      state change as specified in Element
     * @param warning     whether it is a warning or an error
     */
    public SyntaxError(String description, int change, boolean warning) {
        this(description, change);
        this.warning = warning;
    }

    @Override
    public String getErrorMessage() {
        String s = warning ? WARNING : ERROR;
        return s + position + ": " + description;
    }

    /**
     * @return change that happened in Element before it was thrown. -1 if not thrown.
     */
    public int getChange() {
        return change;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    @Override
    public ErrorType getErrorType() {
        return ErrorType.LOGIC;
    }
}
