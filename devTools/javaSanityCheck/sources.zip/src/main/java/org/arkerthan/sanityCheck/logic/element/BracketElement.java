package org.arkerthan.sanityCheck.logic.element;

/**
 * @author Arkerthan
 */
public class BracketElement extends Element {
    //int state = 0;

    public BracketElement(int line, int pos) {
        super(line, pos);
    }

    @Override
    public int handleChar(char c) {
        if (c == ')') {
            return 2;
        } else {
            return 0;
        }
    }

    @Override
    public String getShortDescription() {
        return getPositionAsString() + " (???";
    }
}
